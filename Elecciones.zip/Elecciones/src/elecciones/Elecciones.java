/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elecciones;

import javax.swing.JOptionPane;

/**
 *
 * @author crist
 */
public class Elecciones {

    String[] nombreCandidato;
    int[] nombreMesa;
    int[][] matriz;

    public void crearArrays(int numeroCandidatos, int numeroMesas) {

        nombreCandidato = new String[numeroCandidatos];
        nombreMesa = new int[numeroMesas];

        JOptionPane.showMessageDialog(null, "Correctamente Ingresado");

        for (int l = 0; l < nombreCandidato.length; l++) {
            nombreCandidato[l] = JOptionPane.showInputDialog(null, "ingrese el nombre del candidato" + (l + 1));

        }
        for (int k = 0; k < nombreMesa.length; k++) {
            nombreMesa[k] = k + 1;
        }
        matriz = new int[numeroCandidatos][numeroMesas];

        for (int i = 0; i < numeroCandidatos; i++) {
            for (int j = 0; j < numeroMesas; j++) {

                JOptionPane.showMessageDialog(null, "ingrese el numero de votos de " + nombreCandidato[i]);
                JOptionPane.showInputDialog(null, "en la mesa " + nombreMesa[j]);

            }
        }

    }

}
